import React from "react";
import matchSorter from 'match-sorter';
import { Grid, Button, Form, Input } from 'semantic-ui-react';

const SearchComponent: React.FC<any> = (table :any) =>{

    function filter(event: any) {
        const {value} = event.target;   
       // const filteredData = matchSorter(table.data.resolvedData, value, {keys: ["name","last_name","document_id"], threshold: matchSorter.rankings.WORD_STARTS_WITH})
        table.handleFilter(value);
    }


 

    return (<Grid>
        <Grid.Row>
            <Grid.Column width={10}>
                <Form>
                    <Form.Field>
                        <Input icon='users' iconPosition='left' className="search-input" placeholder='Search person...' onChange={(e) => filter(e)}/>
                    </Form.Field>
                </Form>
            </Grid.Column>
            <Grid.Column width={6}>
                <Button
                    color="green"
                    content="New person"
                    icon="add"
                    labelPosition="left"
                >   
                </Button>
            </Grid.Column>
        </Grid.Row>
    </Grid>);
}


export default SearchComponent;