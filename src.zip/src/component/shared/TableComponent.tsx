import React from "react";
import ReactTable, { Filter } from "react-table";
import { ITableProps } from "../../interfaces/ITableProps";
import { Input, Form, Grid, Button, Icon } from 'semantic-ui-react'
import "../../assets/TableComponent.css"
import matchSorter  from 'match-sorter';
import SearchComponent from './SearchComponent';
import { getMaxListeners } from "cluster";
import { runInThisContext } from "vm";

interface IFilteredProps {
    id: String,
    value: String
}

class TableComponent extends React.Component<ITableProps> {

   state = {
        filteredPeople: Array<any>(),
        filterValue: ""
    }

    constructor(props: ITableProps){
        super(props);
    }
    
    onKeyInputEnter = (filtered: string) =>{
        let filters: Array<Filter> = [{id: "name", value: filtered}, {id: "last_name", value: filtered},{ id: "document_id", value: filtered}]
       if(filtered.length > 0){
           if(filtered.length > 1){
               let filterPeople = this.state.filteredPeople.map(filter => {
                   let filterAct = filters.find(fil => fil.id == filter.id);
                   if(filterAct){
                       filter.value = filterAct.value;
                       return filter;
                   }
               })
                this.setState({filteredPeople: filterPeople})
           }else{
            this.setState((prev:any) => ({filteredPeople: prev.filteredPeople.concat(filters)}))
           }
       }else{
           this.setState({filteredPeople: this.state.filteredPeople.filter(filter => !filters.find(filActual => filActual.id == filter.id ))})
       }
       
    }

    onFilterChange = (changed: any) =>{
        if (this.state.filteredPeople.length > 1 && this.state.filterValue.length) {

            const filterAll = "";
            this.setState({
              filteredPeople: changed.filter((item: any) => item.id != "all"),
              filterValue : filterAll
            });
          } else this.setState({ filteredPeople :changed });
    }

    public render() {
        return <div className="table-margin">
            <ReactTable
                noDataText=""
                loading={this.props.loading}
                data={this.props.data}
                columns={this.props.columns}
                filterable={true}
                filtered={this.state.filteredPeople}
                onFilteredChange={this.onFilterChange}
                defaultPageSize={2}
                pageSizeOptions={[2, 4, 20]}
                 >
                    {(state, makeTable, instance) => {

                        return (<div><SearchComponent data={state} handleFilter={this.onKeyInputEnter}/>{makeTable()}</div>);
                    }}
                </ReactTable>
        </div>;
    }
}

export default TableComponent;